package com.curso.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.curso.model.Pokemon;

/**
 * 
 * @author Javier
 *
 */
public interface PokemonDao extends JpaRepository<Pokemon, Integer>
{
	/**
	 * Query que muestra la consulta para buscar los pokemon por tipo
	 * @param tipo variable que contiene el tipo del pokemon
	 * @return
	 */
	@Query(value="SELECT * FROM pokedex.pokemon where tipo=?",  nativeQuery = true)
	List<Pokemon> pokemonTipo(String tipo);
	
}
