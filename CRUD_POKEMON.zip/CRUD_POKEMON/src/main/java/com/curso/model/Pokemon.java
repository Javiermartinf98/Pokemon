package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 
 * @author Javier
 *
 */
@Entity
@Table(name="pokemon")
public class Pokemon 
{
	/**
	 * @param idpokemon codigo que sera la primary key de la bd
	 * @param nombre nombre que tiene el pokemon
	 * @param tipo el tipo del que es dicho pokemon
	 * @param nivel nivel que tiene 
	 */
	@Id
	private int idpokemon;
	private String nombre;
	private String tipo;
	private int nivel;
	
	/**
	 * Constructor vacio
	 */
	public Pokemon() { }
	
	/**
	 * Constructor por defecto con todos los atributos
	 */
	public Pokemon(int idpokemon, String nombre, String tipo, int nivel) 
	{
		super();
		this.idpokemon = idpokemon;
		this.nombre = nombre;
		this.tipo = tipo;
		this.nivel = nivel;
	}

	/**
	 * Getter y Setters de los atributos de pokemon
	 * @return
	 */
	public int getIdpokemon() {
		return idpokemon;
	}
	public void setIdpokemon(int idpokemon) {
		this.idpokemon = idpokemon;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getNivel() {
		return nivel;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	/**
	 * ToString formateada para la salida por pantalla
	 */
	@Override
	public String toString() 
	{
		return "Pokemon [idpokemon=" + idpokemon + ", nombre=" + nombre + ", tipo=" + tipo + ", nivel=" + nivel + "]";
	}
}
