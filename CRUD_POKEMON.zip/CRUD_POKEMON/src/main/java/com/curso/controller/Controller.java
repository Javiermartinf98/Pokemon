package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Pokemon;
import com.curso.service.PokemonService;

/**
 * 
 * @author Javier
 *
 */
@RestController
public class Controller 
{
	@Autowired
	PokemonService service;
	
	/**
	 * Metodo GET que muestra todos los pokemon
	 * @return
	 */
	@GetMapping(value="pokemons", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Pokemon> pokemons() 
	{
		return service.pokemons();
	}
	
	/**
	 * Metodo GET que muestra por tipos los pokemon existentes
	 * @param tipo
	 * @return
	 */
	//http://localhost:8500/pokemon/{tipo}
	@GetMapping(value="pokemon/{tipo}", produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Pokemon> pokemonTipo(@PathVariable("tipo") String tipo)
	{
		return service.pokemonTipo(tipo);
	}
	
	/**
	 * Metodo Post que inserta un pokemon
	 * @param p
	 */
	//http://localhost:8500/pokemon
	@PostMapping(value="pokemon", consumes= MediaType.APPLICATION_JSON_VALUE)
	public void altaPokemon(@RequestBody Pokemon p)
	{
		service.altaPokemon(p);
	}
		
	/**
	 * Metodo PUT que modifica al pokemon
	 * @param p
	 */
	//http://localhost:8500/pokemon
	@PutMapping(value="pokemon", consumes=MediaType.APPLICATION_JSON_VALUE)
	public void actualizarPokemon(@RequestBody Pokemon p)
	{
		service.actualizarPokemon(p);
	}
		
	/**
	 * Metodo DELETE que elimina al pokemon
	 * @param idpokemon
	 * @return
	 */
	//http://localhost:8500/pokemon/{idpokemon}
	@DeleteMapping(value="pokemon/{idpokemon}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Pokemon> EliminarPokemon(@PathVariable int idpokemon)
	{
		return service.EliminarPokemon(idpokemon);
	}
		
}
