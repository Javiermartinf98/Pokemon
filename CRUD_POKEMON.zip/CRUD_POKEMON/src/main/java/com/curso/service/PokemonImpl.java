package com.curso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.dao.PokemonDao;
import com.curso.model.Pokemon;

/**
 * 
 * @author Javier
 *
 */
@Service
public class PokemonImpl implements PokemonService
{
	@Autowired
	PokemonDao dao;

	/**
	 * Lista todos los pokemon de la BD
	 */
	@Override
	public List<Pokemon> pokemons() 
	{
		return dao.findAll();
	}

	/**
	 * Lista los pokemon por tipo de la BD
	 */
	@Override
	public List<Pokemon> pokemonTipo(String tipo) 
	{
	
		return dao.pokemonTipo(tipo);
	}

	/**
	 * Busca un pokemon dentro de la BD
	 */
	@Override
	public Pokemon buscarPokemon(int idpokemon) 
	{
		return dao.findById(idpokemon).orElse(null);
	}

	/**
	 * Inserta un nuevo pokemon en la BD
	 */
	@Override
	public void altaPokemon(Pokemon p) 
	{
		dao.save(p);
	}

	/**
	 * Modifica los datos del pokemon de la BD
	 */
	@Override
	public void actualizarPokemon(Pokemon p) 
	{
		dao.save(p);
	}

	/**
	 * Elimina un pokemon de la BD
	 */
	@Override
	public List<Pokemon> EliminarPokemon(int idpokemon) 
	{
		dao.deleteById(idpokemon);
		return dao.findAll();
	}

}
