package com.curso.service;

import java.util.List;

import com.curso.model.Pokemon;

/**
 * 
 * @author Javier
 *
 */
public interface PokemonService 
{
	/**
	 * Este metodo devuelve la lista de todos los pokemon que esten en la bd
	 * @return
	 */
	List<Pokemon> pokemons();
	
	/**
	 * Este metodo devuelve unicamente los pokemon que sean del tipo
	 * @param tipo variable a poner que selecciona solo a dichos pokemon
	 * @return
	 */
	List<Pokemon> pokemonTipo(String tipo);
	
	/**
	 * Metodo que busca al pokemon segun el codigo que pongas
	 * @param idpokemon 
	 * @return
	 */
	Pokemon buscarPokemon(int idpokemon);
	
	/**
	 * Metodo que inserta un pokemon a traves del objeto Pokemon y luego los lista 
	 * @param p
	 */
	void altaPokemon(Pokemon p);
	
	/**
	 * Metodo que actualiza el pokemon segun el objeto pokemon que se le ponga
	 * @param p
	 */
	void actualizarPokemon(Pokemon p);
	
	/**
	 * Metodo que elimina al pokemon segun el id que pongas y despues los lista
	 * @param idpokemon
	 * @return
	 */
	List<Pokemon> EliminarPokemon(int idpokemon);
}
